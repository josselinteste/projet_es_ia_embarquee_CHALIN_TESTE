/**
  ******************************************************************************
  * @file    cifar10.c
  * @author  AST Embedded Analytics Research Platform
  * @date    2025-11-01T15:17:15+0100
  * @brief   AI Tool Automatic Code Generator for Embedded NN computing
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  ******************************************************************************
  */


#include "cifar10.h"
#include "cifar10_data.h"

#include "ai_platform.h"
#include "ai_platform_interface.h"
#include "ai_math_helpers.h"

#include "core_common.h"
#include "core_convert.h"

#include "layers.h"



#undef AI_NET_OBJ_INSTANCE
#define AI_NET_OBJ_INSTANCE g_cifar10
 
#undef AI_CIFAR10_MODEL_SIGNATURE
#define AI_CIFAR10_MODEL_SIGNATURE     "0x6a9dd80e2af4ebbc648536c72f8667be"

#ifndef AI_TOOLS_REVISION_ID
#define AI_TOOLS_REVISION_ID     ""
#endif

#undef AI_TOOLS_DATE_TIME
#define AI_TOOLS_DATE_TIME   "2025-11-01T15:17:15+0100"

#undef AI_TOOLS_COMPILE_TIME
#define AI_TOOLS_COMPILE_TIME    __DATE__ " " __TIME__

#undef AI_CIFAR10_N_BATCHES
#define AI_CIFAR10_N_BATCHES         (1)

static ai_ptr g_cifar10_activations_map[1] = AI_C_ARRAY_INIT;
static ai_ptr g_cifar10_weights_map[1] = AI_C_ARRAY_INIT;



/**  Array declarations section  **********************************************/
/* Array#0 */
AI_ARRAY_OBJ_DECLARE(
  input_output_array, AI_ARRAY_FORMAT_FLOAT|AI_FMT_FLAG_IS_IO,
  NULL, NULL, 3072, AI_STATIC)

/* Array#1 */
AI_ARRAY_OBJ_DECLARE(
  input_Transpose_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 3072, AI_STATIC)

/* Array#2 */
AI_ARRAY_OBJ_DECLARE(
  _0_Conv_output_0_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 21142, AI_STATIC)

/* Array#3 */
AI_ARRAY_OBJ_DECLARE(
  _1_Relu_output_0_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 21142, AI_STATIC)

/* Array#4 */
AI_ARRAY_OBJ_DECLARE(
  _2_BatchNormalization_output_0_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 21142, AI_STATIC)

/* Array#5 */
AI_ARRAY_OBJ_DECLARE(
  _3_Conv_output_0_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 19800, AI_STATIC)

/* Array#6 */
AI_ARRAY_OBJ_DECLARE(
  _4_Relu_output_0_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 19800, AI_STATIC)

/* Array#7 */
AI_ARRAY_OBJ_DECLARE(
  _5_BatchNormalization_output_0_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 19800, AI_STATIC)

/* Array#8 */
AI_ARRAY_OBJ_DECLARE(
  _6_MaxPool_output_0_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 4950, AI_STATIC)

/* Array#9 */
AI_ARRAY_OBJ_DECLARE(
  _8_Conv_output_0_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 8624, AI_STATIC)

/* Array#10 */
AI_ARRAY_OBJ_DECLARE(
  _9_Relu_output_0_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 8624, AI_STATIC)

/* Array#11 */
AI_ARRAY_OBJ_DECLARE(
  _10_BatchNormalization_output_0_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 8624, AI_STATIC)

/* Array#12 */
AI_ARRAY_OBJ_DECLARE(
  _11_Conv_output_0_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 7436, AI_STATIC)

/* Array#13 */
AI_ARRAY_OBJ_DECLARE(
  _12_Relu_output_0_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 7436, AI_STATIC)

/* Array#14 */
AI_ARRAY_OBJ_DECLARE(
  _13_BatchNormalization_output_0_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 7436, AI_STATIC)

/* Array#15 */
AI_ARRAY_OBJ_DECLARE(
  _14_MaxPool_output_0_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 1584, AI_STATIC)

/* Array#16 */
AI_ARRAY_OBJ_DECLARE(
  _16_Conv_output_0_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 2225, AI_STATIC)

/* Array#17 */
AI_ARRAY_OBJ_DECLARE(
  _17_Relu_output_0_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 2225, AI_STATIC)

/* Array#18 */
AI_ARRAY_OBJ_DECLARE(
  _19_Conv_output_0_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 3200, AI_STATIC)

/* Array#19 */
AI_ARRAY_OBJ_DECLARE(
  _20_Relu_output_0_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 3200, AI_STATIC)

/* Array#20 */
AI_ARRAY_OBJ_DECLARE(
  _21_BatchNormalization_output_0_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 3200, AI_STATIC)

/* Array#21 */
AI_ARRAY_OBJ_DECLARE(
  _22_GlobalAveragePool_output_0_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 128, AI_STATIC)

/* Array#22 */
AI_ARRAY_OBJ_DECLARE(
  _24_Gemm_output_0_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 128, AI_STATIC)

/* Array#23 */
AI_ARRAY_OBJ_DECLARE(
  _25_Relu_output_0_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 128, AI_STATIC)

/* Array#24 */
AI_ARRAY_OBJ_DECLARE(
  output_output_array, AI_ARRAY_FORMAT_FLOAT|AI_FMT_FLAG_IS_IO,
  NULL, NULL, 10, AI_STATIC)

/* Array#25 */
AI_ARRAY_OBJ_DECLARE(
  _0_Conv_output_0_weights_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 1056, AI_STATIC)

/* Array#26 */
AI_ARRAY_OBJ_DECLARE(
  _0_Conv_output_0_bias_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 22, AI_STATIC)

/* Array#27 */
AI_ARRAY_OBJ_DECLARE(
  _2_BatchNormalization_output_0_scale_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 22, AI_STATIC)

/* Array#28 */
AI_ARRAY_OBJ_DECLARE(
  _2_BatchNormalization_output_0_bias_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 22, AI_STATIC)

/* Array#29 */
AI_ARRAY_OBJ_DECLARE(
  _3_Conv_output_0_weights_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 7744, AI_STATIC)

/* Array#30 */
AI_ARRAY_OBJ_DECLARE(
  _3_Conv_output_0_bias_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 22, AI_STATIC)

/* Array#31 */
AI_ARRAY_OBJ_DECLARE(
  _5_BatchNormalization_output_0_scale_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 22, AI_STATIC)

/* Array#32 */
AI_ARRAY_OBJ_DECLARE(
  _5_BatchNormalization_output_0_bias_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 22, AI_STATIC)

/* Array#33 */
AI_ARRAY_OBJ_DECLARE(
  _8_Conv_output_0_weights_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 15488, AI_STATIC)

/* Array#34 */
AI_ARRAY_OBJ_DECLARE(
  _8_Conv_output_0_bias_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 44, AI_STATIC)

/* Array#35 */
AI_ARRAY_OBJ_DECLARE(
  _10_BatchNormalization_output_0_scale_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 44, AI_STATIC)

/* Array#36 */
AI_ARRAY_OBJ_DECLARE(
  _10_BatchNormalization_output_0_bias_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 44, AI_STATIC)

/* Array#37 */
AI_ARRAY_OBJ_DECLARE(
  _11_Conv_output_0_weights_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 30976, AI_STATIC)

/* Array#38 */
AI_ARRAY_OBJ_DECLARE(
  _11_Conv_output_0_bias_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 44, AI_STATIC)

/* Array#39 */
AI_ARRAY_OBJ_DECLARE(
  _13_BatchNormalization_output_0_scale_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 44, AI_STATIC)

/* Array#40 */
AI_ARRAY_OBJ_DECLARE(
  _13_BatchNormalization_output_0_bias_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 44, AI_STATIC)

/* Array#41 */
AI_ARRAY_OBJ_DECLARE(
  _16_Conv_output_0_weights_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 62656, AI_STATIC)

/* Array#42 */
AI_ARRAY_OBJ_DECLARE(
  _16_Conv_output_0_bias_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 89, AI_STATIC)

/* Array#43 */
AI_ARRAY_OBJ_DECLARE(
  _19_Conv_output_0_weights_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 11392, AI_STATIC)

/* Array#44 */
AI_ARRAY_OBJ_DECLARE(
  _19_Conv_output_0_bias_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 128, AI_STATIC)

/* Array#45 */
AI_ARRAY_OBJ_DECLARE(
  _21_BatchNormalization_output_0_scale_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 128, AI_STATIC)

/* Array#46 */
AI_ARRAY_OBJ_DECLARE(
  _21_BatchNormalization_output_0_bias_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 128, AI_STATIC)

/* Array#47 */
AI_ARRAY_OBJ_DECLARE(
  _24_Gemm_output_0_weights_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 16384, AI_STATIC)

/* Array#48 */
AI_ARRAY_OBJ_DECLARE(
  _24_Gemm_output_0_bias_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 128, AI_STATIC)

/* Array#49 */
AI_ARRAY_OBJ_DECLARE(
  output_weights_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 1280, AI_STATIC)

/* Array#50 */
AI_ARRAY_OBJ_DECLARE(
  output_bias_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 10, AI_STATIC)

/* Array#51 */
AI_ARRAY_OBJ_DECLARE(
  _0_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 48, AI_STATIC)

/* Array#52 */
AI_ARRAY_OBJ_DECLARE(
  _3_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 352, AI_STATIC)

/* Array#53 */
AI_ARRAY_OBJ_DECLARE(
  _8_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 352, AI_STATIC)

/* Array#54 */
AI_ARRAY_OBJ_DECLARE(
  _11_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 704, AI_STATIC)

/* Array#55 */
AI_ARRAY_OBJ_DECLARE(
  _16_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 704, AI_STATIC)

/* Array#56 */
AI_ARRAY_OBJ_DECLARE(
  _19_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 89, AI_STATIC)

/**  Tensor declarations section  *********************************************/
/* Tensor #0 */
AI_TENSOR_OBJ_DECLARE(
  _0_Conv_output_0_bias, AI_STATIC,
  0, 0x0,
  AI_SHAPE_INIT(4, 1, 22, 1, 1), AI_STRIDE_INIT(4, 4, 4, 88, 88),
  1, &_0_Conv_output_0_bias_array, NULL)

/* Tensor #1 */
AI_TENSOR_OBJ_DECLARE(
  _0_Conv_output_0_output, AI_STATIC,
  1, 0x0,
  AI_SHAPE_INIT(4, 1, 22, 31, 31), AI_STRIDE_INIT(4, 4, 4, 88, 2728),
  1, &_0_Conv_output_0_output_array, NULL)

/* Tensor #2 */
AI_TENSOR_OBJ_DECLARE(
  _0_Conv_output_0_scratch0, AI_STATIC,
  2, 0x0,
  AI_SHAPE_INIT(4, 1, 3, 4, 4), AI_STRIDE_INIT(4, 4, 4, 12, 48),
  1, &_0_Conv_output_0_scratch0_array, NULL)

/* Tensor #3 */
AI_TENSOR_OBJ_DECLARE(
  _0_Conv_output_0_weights, AI_STATIC,
  3, 0x0,
  AI_SHAPE_INIT(4, 3, 4, 4, 22), AI_STRIDE_INIT(4, 4, 12, 264, 1056),
  1, &_0_Conv_output_0_weights_array, NULL)

/* Tensor #4 */
AI_TENSOR_OBJ_DECLARE(
  _10_BatchNormalization_output_0_bias, AI_STATIC,
  4, 0x0,
  AI_SHAPE_INIT(4, 1, 44, 1, 1), AI_STRIDE_INIT(4, 4, 4, 176, 176),
  1, &_10_BatchNormalization_output_0_bias_array, NULL)

/* Tensor #5 */
AI_TENSOR_OBJ_DECLARE(
  _10_BatchNormalization_output_0_output, AI_STATIC,
  5, 0x0,
  AI_SHAPE_INIT(4, 1, 44, 14, 14), AI_STRIDE_INIT(4, 4, 4, 176, 2464),
  1, &_10_BatchNormalization_output_0_output_array, NULL)

/* Tensor #6 */
AI_TENSOR_OBJ_DECLARE(
  _10_BatchNormalization_output_0_scale, AI_STATIC,
  6, 0x0,
  AI_SHAPE_INIT(4, 1, 44, 1, 1), AI_STRIDE_INIT(4, 4, 4, 176, 176),
  1, &_10_BatchNormalization_output_0_scale_array, NULL)

/* Tensor #7 */
AI_TENSOR_OBJ_DECLARE(
  _11_Conv_output_0_bias, AI_STATIC,
  7, 0x0,
  AI_SHAPE_INIT(4, 1, 44, 1, 1), AI_STRIDE_INIT(4, 4, 4, 176, 176),
  1, &_11_Conv_output_0_bias_array, NULL)

/* Tensor #8 */
AI_TENSOR_OBJ_DECLARE(
  _11_Conv_output_0_output, AI_STATIC,
  8, 0x0,
  AI_SHAPE_INIT(4, 1, 44, 13, 13), AI_STRIDE_INIT(4, 4, 4, 176, 2288),
  1, &_11_Conv_output_0_output_array, NULL)

/* Tensor #9 */
AI_TENSOR_OBJ_DECLARE(
  _11_Conv_output_0_scratch0, AI_STATIC,
  9, 0x0,
  AI_SHAPE_INIT(4, 1, 44, 4, 4), AI_STRIDE_INIT(4, 4, 4, 176, 704),
  1, &_11_Conv_output_0_scratch0_array, NULL)

/* Tensor #10 */
AI_TENSOR_OBJ_DECLARE(
  _11_Conv_output_0_weights, AI_STATIC,
  10, 0x0,
  AI_SHAPE_INIT(4, 44, 4, 4, 44), AI_STRIDE_INIT(4, 4, 176, 7744, 30976),
  1, &_11_Conv_output_0_weights_array, NULL)

/* Tensor #11 */
AI_TENSOR_OBJ_DECLARE(
  _12_Relu_output_0_output, AI_STATIC,
  11, 0x0,
  AI_SHAPE_INIT(4, 1, 44, 13, 13), AI_STRIDE_INIT(4, 4, 4, 176, 2288),
  1, &_12_Relu_output_0_output_array, NULL)

/* Tensor #12 */
AI_TENSOR_OBJ_DECLARE(
  _13_BatchNormalization_output_0_bias, AI_STATIC,
  12, 0x0,
  AI_SHAPE_INIT(4, 1, 44, 1, 1), AI_STRIDE_INIT(4, 4, 4, 176, 176),
  1, &_13_BatchNormalization_output_0_bias_array, NULL)

/* Tensor #13 */
AI_TENSOR_OBJ_DECLARE(
  _13_BatchNormalization_output_0_output, AI_STATIC,
  13, 0x0,
  AI_SHAPE_INIT(4, 1, 44, 13, 13), AI_STRIDE_INIT(4, 4, 4, 176, 2288),
  1, &_13_BatchNormalization_output_0_output_array, NULL)

/* Tensor #14 */
AI_TENSOR_OBJ_DECLARE(
  _13_BatchNormalization_output_0_scale, AI_STATIC,
  14, 0x0,
  AI_SHAPE_INIT(4, 1, 44, 1, 1), AI_STRIDE_INIT(4, 4, 4, 176, 176),
  1, &_13_BatchNormalization_output_0_scale_array, NULL)

/* Tensor #15 */
AI_TENSOR_OBJ_DECLARE(
  _14_MaxPool_output_0_output, AI_STATIC,
  15, 0x0,
  AI_SHAPE_INIT(4, 1, 44, 6, 6), AI_STRIDE_INIT(4, 4, 4, 176, 1056),
  1, &_14_MaxPool_output_0_output_array, NULL)

/* Tensor #16 */
AI_TENSOR_OBJ_DECLARE(
  _16_Conv_output_0_bias, AI_STATIC,
  16, 0x0,
  AI_SHAPE_INIT(4, 1, 89, 1, 1), AI_STRIDE_INIT(4, 4, 4, 356, 356),
  1, &_16_Conv_output_0_bias_array, NULL)

/* Tensor #17 */
AI_TENSOR_OBJ_DECLARE(
  _16_Conv_output_0_output, AI_STATIC,
  17, 0x0,
  AI_SHAPE_INIT(4, 1, 89, 5, 5), AI_STRIDE_INIT(4, 4, 4, 356, 1780),
  1, &_16_Conv_output_0_output_array, NULL)

/* Tensor #18 */
AI_TENSOR_OBJ_DECLARE(
  _16_Conv_output_0_scratch0, AI_STATIC,
  18, 0x0,
  AI_SHAPE_INIT(4, 1, 44, 4, 4), AI_STRIDE_INIT(4, 4, 4, 176, 704),
  1, &_16_Conv_output_0_scratch0_array, NULL)

/* Tensor #19 */
AI_TENSOR_OBJ_DECLARE(
  _16_Conv_output_0_weights, AI_STATIC,
  19, 0x0,
  AI_SHAPE_INIT(4, 44, 4, 4, 89), AI_STRIDE_INIT(4, 4, 176, 15664, 62656),
  1, &_16_Conv_output_0_weights_array, NULL)

/* Tensor #20 */
AI_TENSOR_OBJ_DECLARE(
  _17_Relu_output_0_output, AI_STATIC,
  20, 0x0,
  AI_SHAPE_INIT(4, 1, 89, 5, 5), AI_STRIDE_INIT(4, 4, 4, 356, 1780),
  1, &_17_Relu_output_0_output_array, NULL)

/* Tensor #21 */
AI_TENSOR_OBJ_DECLARE(
  _19_Conv_output_0_bias, AI_STATIC,
  21, 0x0,
  AI_SHAPE_INIT(4, 1, 128, 1, 1), AI_STRIDE_INIT(4, 4, 4, 512, 512),
  1, &_19_Conv_output_0_bias_array, NULL)

/* Tensor #22 */
AI_TENSOR_OBJ_DECLARE(
  _19_Conv_output_0_output, AI_STATIC,
  22, 0x0,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 4, 4, 512, 2560),
  1, &_19_Conv_output_0_output_array, NULL)

/* Tensor #23 */
AI_TENSOR_OBJ_DECLARE(
  _19_Conv_output_0_scratch0, AI_STATIC,
  23, 0x0,
  AI_SHAPE_INIT(4, 1, 89, 1, 1), AI_STRIDE_INIT(4, 4, 4, 356, 356),
  1, &_19_Conv_output_0_scratch0_array, NULL)

/* Tensor #24 */
AI_TENSOR_OBJ_DECLARE(
  _19_Conv_output_0_weights, AI_STATIC,
  24, 0x0,
  AI_SHAPE_INIT(4, 89, 1, 1, 128), AI_STRIDE_INIT(4, 4, 356, 45568, 45568),
  1, &_19_Conv_output_0_weights_array, NULL)

/* Tensor #25 */
AI_TENSOR_OBJ_DECLARE(
  _1_Relu_output_0_output, AI_STATIC,
  25, 0x0,
  AI_SHAPE_INIT(4, 1, 22, 31, 31), AI_STRIDE_INIT(4, 4, 4, 88, 2728),
  1, &_1_Relu_output_0_output_array, NULL)

/* Tensor #26 */
AI_TENSOR_OBJ_DECLARE(
  _20_Relu_output_0_output, AI_STATIC,
  26, 0x0,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 4, 4, 512, 2560),
  1, &_20_Relu_output_0_output_array, NULL)

/* Tensor #27 */
AI_TENSOR_OBJ_DECLARE(
  _21_BatchNormalization_output_0_bias, AI_STATIC,
  27, 0x0,
  AI_SHAPE_INIT(4, 1, 128, 1, 1), AI_STRIDE_INIT(4, 4, 4, 512, 512),
  1, &_21_BatchNormalization_output_0_bias_array, NULL)

/* Tensor #28 */
AI_TENSOR_OBJ_DECLARE(
  _21_BatchNormalization_output_0_output, AI_STATIC,
  28, 0x0,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 4, 4, 512, 2560),
  1, &_21_BatchNormalization_output_0_output_array, NULL)

/* Tensor #29 */
AI_TENSOR_OBJ_DECLARE(
  _21_BatchNormalization_output_0_scale, AI_STATIC,
  29, 0x0,
  AI_SHAPE_INIT(4, 1, 128, 1, 1), AI_STRIDE_INIT(4, 4, 4, 512, 512),
  1, &_21_BatchNormalization_output_0_scale_array, NULL)

/* Tensor #30 */
AI_TENSOR_OBJ_DECLARE(
  _22_GlobalAveragePool_output_0_output, AI_STATIC,
  30, 0x0,
  AI_SHAPE_INIT(4, 1, 128, 1, 1), AI_STRIDE_INIT(4, 4, 4, 512, 512),
  1, &_22_GlobalAveragePool_output_0_output_array, NULL)

/* Tensor #31 */
AI_TENSOR_OBJ_DECLARE(
  _24_Gemm_output_0_bias, AI_STATIC,
  31, 0x0,
  AI_SHAPE_INIT(4, 1, 128, 1, 1), AI_STRIDE_INIT(4, 4, 4, 512, 512),
  1, &_24_Gemm_output_0_bias_array, NULL)

/* Tensor #32 */
AI_TENSOR_OBJ_DECLARE(
  _24_Gemm_output_0_output, AI_STATIC,
  32, 0x0,
  AI_SHAPE_INIT(4, 1, 128, 1, 1), AI_STRIDE_INIT(4, 4, 4, 512, 512),
  1, &_24_Gemm_output_0_output_array, NULL)

/* Tensor #33 */
AI_TENSOR_OBJ_DECLARE(
  _24_Gemm_output_0_weights, AI_STATIC,
  33, 0x0,
  AI_SHAPE_INIT(4, 128, 128, 1, 1), AI_STRIDE_INIT(4, 4, 512, 65536, 65536),
  1, &_24_Gemm_output_0_weights_array, NULL)

/* Tensor #34 */
AI_TENSOR_OBJ_DECLARE(
  _25_Relu_output_0_output, AI_STATIC,
  34, 0x0,
  AI_SHAPE_INIT(4, 1, 128, 1, 1), AI_STRIDE_INIT(4, 4, 4, 512, 512),
  1, &_25_Relu_output_0_output_array, NULL)

/* Tensor #35 */
AI_TENSOR_OBJ_DECLARE(
  _2_BatchNormalization_output_0_bias, AI_STATIC,
  35, 0x0,
  AI_SHAPE_INIT(4, 1, 22, 1, 1), AI_STRIDE_INIT(4, 4, 4, 88, 88),
  1, &_2_BatchNormalization_output_0_bias_array, NULL)

/* Tensor #36 */
AI_TENSOR_OBJ_DECLARE(
  _2_BatchNormalization_output_0_output, AI_STATIC,
  36, 0x0,
  AI_SHAPE_INIT(4, 1, 22, 31, 31), AI_STRIDE_INIT(4, 4, 4, 88, 2728),
  1, &_2_BatchNormalization_output_0_output_array, NULL)

/* Tensor #37 */
AI_TENSOR_OBJ_DECLARE(
  _2_BatchNormalization_output_0_scale, AI_STATIC,
  37, 0x0,
  AI_SHAPE_INIT(4, 1, 22, 1, 1), AI_STRIDE_INIT(4, 4, 4, 88, 88),
  1, &_2_BatchNormalization_output_0_scale_array, NULL)

/* Tensor #38 */
AI_TENSOR_OBJ_DECLARE(
  _3_Conv_output_0_bias, AI_STATIC,
  38, 0x0,
  AI_SHAPE_INIT(4, 1, 22, 1, 1), AI_STRIDE_INIT(4, 4, 4, 88, 88),
  1, &_3_Conv_output_0_bias_array, NULL)

/* Tensor #39 */
AI_TENSOR_OBJ_DECLARE(
  _3_Conv_output_0_output, AI_STATIC,
  39, 0x0,
  AI_SHAPE_INIT(4, 1, 22, 30, 30), AI_STRIDE_INIT(4, 4, 4, 88, 2640),
  1, &_3_Conv_output_0_output_array, NULL)

/* Tensor #40 */
AI_TENSOR_OBJ_DECLARE(
  _3_Conv_output_0_scratch0, AI_STATIC,
  40, 0x0,
  AI_SHAPE_INIT(4, 1, 22, 4, 4), AI_STRIDE_INIT(4, 4, 4, 88, 352),
  1, &_3_Conv_output_0_scratch0_array, NULL)

/* Tensor #41 */
AI_TENSOR_OBJ_DECLARE(
  _3_Conv_output_0_weights, AI_STATIC,
  41, 0x0,
  AI_SHAPE_INIT(4, 22, 4, 4, 22), AI_STRIDE_INIT(4, 4, 88, 1936, 7744),
  1, &_3_Conv_output_0_weights_array, NULL)

/* Tensor #42 */
AI_TENSOR_OBJ_DECLARE(
  _4_Relu_output_0_output, AI_STATIC,
  42, 0x0,
  AI_SHAPE_INIT(4, 1, 22, 30, 30), AI_STRIDE_INIT(4, 4, 4, 88, 2640),
  1, &_4_Relu_output_0_output_array, NULL)

/* Tensor #43 */
AI_TENSOR_OBJ_DECLARE(
  _5_BatchNormalization_output_0_bias, AI_STATIC,
  43, 0x0,
  AI_SHAPE_INIT(4, 1, 22, 1, 1), AI_STRIDE_INIT(4, 4, 4, 88, 88),
  1, &_5_BatchNormalization_output_0_bias_array, NULL)

/* Tensor #44 */
AI_TENSOR_OBJ_DECLARE(
  _5_BatchNormalization_output_0_output, AI_STATIC,
  44, 0x0,
  AI_SHAPE_INIT(4, 1, 22, 30, 30), AI_STRIDE_INIT(4, 4, 4, 88, 2640),
  1, &_5_BatchNormalization_output_0_output_array, NULL)

/* Tensor #45 */
AI_TENSOR_OBJ_DECLARE(
  _5_BatchNormalization_output_0_scale, AI_STATIC,
  45, 0x0,
  AI_SHAPE_INIT(4, 1, 22, 1, 1), AI_STRIDE_INIT(4, 4, 4, 88, 88),
  1, &_5_BatchNormalization_output_0_scale_array, NULL)

/* Tensor #46 */
AI_TENSOR_OBJ_DECLARE(
  _6_MaxPool_output_0_output, AI_STATIC,
  46, 0x0,
  AI_SHAPE_INIT(4, 1, 22, 15, 15), AI_STRIDE_INIT(4, 4, 4, 88, 1320),
  1, &_6_MaxPool_output_0_output_array, NULL)

/* Tensor #47 */
AI_TENSOR_OBJ_DECLARE(
  _8_Conv_output_0_bias, AI_STATIC,
  47, 0x0,
  AI_SHAPE_INIT(4, 1, 44, 1, 1), AI_STRIDE_INIT(4, 4, 4, 176, 176),
  1, &_8_Conv_output_0_bias_array, NULL)

/* Tensor #48 */
AI_TENSOR_OBJ_DECLARE(
  _8_Conv_output_0_output, AI_STATIC,
  48, 0x0,
  AI_SHAPE_INIT(4, 1, 44, 14, 14), AI_STRIDE_INIT(4, 4, 4, 176, 2464),
  1, &_8_Conv_output_0_output_array, NULL)

/* Tensor #49 */
AI_TENSOR_OBJ_DECLARE(
  _8_Conv_output_0_scratch0, AI_STATIC,
  49, 0x0,
  AI_SHAPE_INIT(4, 1, 22, 4, 4), AI_STRIDE_INIT(4, 4, 4, 88, 352),
  1, &_8_Conv_output_0_scratch0_array, NULL)

/* Tensor #50 */
AI_TENSOR_OBJ_DECLARE(
  _8_Conv_output_0_weights, AI_STATIC,
  50, 0x0,
  AI_SHAPE_INIT(4, 22, 4, 4, 44), AI_STRIDE_INIT(4, 4, 88, 3872, 15488),
  1, &_8_Conv_output_0_weights_array, NULL)

/* Tensor #51 */
AI_TENSOR_OBJ_DECLARE(
  _9_Relu_output_0_output, AI_STATIC,
  51, 0x0,
  AI_SHAPE_INIT(4, 1, 44, 14, 14), AI_STRIDE_INIT(4, 4, 4, 176, 2464),
  1, &_9_Relu_output_0_output_array, NULL)

/* Tensor #52 */
AI_TENSOR_OBJ_DECLARE(
  input_Transpose_output, AI_STATIC,
  52, 0x0,
  AI_SHAPE_INIT(4, 1, 3, 32, 32), AI_STRIDE_INIT(4, 4, 4, 12, 384),
  1, &input_Transpose_output_array, NULL)

/* Tensor #53 */
AI_TENSOR_OBJ_DECLARE(
  input_output, AI_STATIC,
  53, 0x0,
  AI_SHAPE_INIT(4, 1, 32, 32, 3), AI_STRIDE_INIT(4, 4, 4, 128, 4096),
  1, &input_output_array, NULL)

/* Tensor #54 */
AI_TENSOR_OBJ_DECLARE(
  output_bias, AI_STATIC,
  54, 0x0,
  AI_SHAPE_INIT(4, 1, 10, 1, 1), AI_STRIDE_INIT(4, 4, 4, 40, 40),
  1, &output_bias_array, NULL)

/* Tensor #55 */
AI_TENSOR_OBJ_DECLARE(
  output_output, AI_STATIC,
  55, 0x0,
  AI_SHAPE_INIT(4, 1, 10, 1, 1), AI_STRIDE_INIT(4, 4, 4, 40, 40),
  1, &output_output_array, NULL)

/* Tensor #56 */
AI_TENSOR_OBJ_DECLARE(
  output_weights, AI_STATIC,
  56, 0x0,
  AI_SHAPE_INIT(4, 128, 10, 1, 1), AI_STRIDE_INIT(4, 4, 512, 5120, 5120),
  1, &output_weights_array, NULL)



/**  Layer declarations section  **********************************************/


AI_TENSOR_CHAIN_OBJ_DECLARE(
  output_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_25_Relu_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &output_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &output_weights, &output_bias),
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  output_layer, 25,
  DENSE_TYPE, 0x0, NULL,
  dense, forward_dense,
  &output_chain,
  NULL, &output_layer, AI_STATIC, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _25_Relu_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_24_Gemm_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_25_Relu_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _25_Relu_output_0_layer, 24,
  NL_TYPE, 0x0, NULL,
  nl, forward_relu,
  &_25_Relu_output_0_chain,
  NULL, &output_layer, AI_STATIC, 
  .nl_params = NULL, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _24_Gemm_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_22_GlobalAveragePool_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_24_Gemm_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_24_Gemm_output_0_weights, &_24_Gemm_output_0_bias),
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _24_Gemm_output_0_layer, 23,
  DENSE_TYPE, 0x0, NULL,
  dense, forward_dense,
  &_24_Gemm_output_0_chain,
  NULL, &_25_Relu_output_0_layer, AI_STATIC, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _22_GlobalAveragePool_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_21_BatchNormalization_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_22_GlobalAveragePool_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _22_GlobalAveragePool_output_0_layer, 21,
  POOL_TYPE, 0x0, NULL,
  pool, forward_ap,
  &_22_GlobalAveragePool_output_0_chain,
  NULL, &_24_Gemm_output_0_layer, AI_STATIC, 
  .pool_size = AI_SHAPE_2D_INIT(5, 5), 
  .pool_stride = AI_SHAPE_2D_INIT(5, 5), 
  .pool_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _21_BatchNormalization_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_20_Relu_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_21_BatchNormalization_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_21_BatchNormalization_output_0_scale, &_21_BatchNormalization_output_0_bias),
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _21_BatchNormalization_output_0_layer, 20,
  BN_TYPE, 0x0, NULL,
  bn, forward_bn,
  &_21_BatchNormalization_output_0_chain,
  NULL, &_22_GlobalAveragePool_output_0_layer, AI_STATIC, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _20_Relu_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_19_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_20_Relu_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _20_Relu_output_0_layer, 19,
  NL_TYPE, 0x0, NULL,
  nl, forward_relu,
  &_20_Relu_output_0_chain,
  NULL, &_21_BatchNormalization_output_0_layer, AI_STATIC, 
  .nl_params = NULL, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _19_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_17_Relu_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_19_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_19_Conv_output_0_weights, &_19_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_19_Conv_output_0_scratch0, NULL)
)

AI_LAYER_OBJ_DECLARE(
  _19_Conv_output_0_layer, 18,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_if32of32wf32,
  &_19_Conv_output_0_chain,
  NULL, &_20_Relu_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _17_Relu_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_16_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_17_Relu_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _17_Relu_output_0_layer, 16,
  NL_TYPE, 0x0, NULL,
  nl, forward_relu,
  &_17_Relu_output_0_chain,
  NULL, &_19_Conv_output_0_layer, AI_STATIC, 
  .nl_params = NULL, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _16_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_14_MaxPool_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_16_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_16_Conv_output_0_weights, &_16_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_16_Conv_output_0_scratch0, NULL)
)

AI_LAYER_OBJ_DECLARE(
  _16_Conv_output_0_layer, 15,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_if32of32wf32,
  &_16_Conv_output_0_chain,
  NULL, &_17_Relu_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_SAME, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _14_MaxPool_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_13_BatchNormalization_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_14_MaxPool_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _14_MaxPool_output_0_layer, 14,
  POOL_TYPE, 0x0, NULL,
  pool, forward_mp,
  &_14_MaxPool_output_0_chain,
  NULL, &_16_Conv_output_0_layer, AI_STATIC, 
  .pool_size = AI_SHAPE_2D_INIT(2, 2), 
  .pool_stride = AI_SHAPE_2D_INIT(2, 2), 
  .pool_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _13_BatchNormalization_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_12_Relu_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_13_BatchNormalization_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_13_BatchNormalization_output_0_scale, &_13_BatchNormalization_output_0_bias),
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _13_BatchNormalization_output_0_layer, 13,
  BN_TYPE, 0x0, NULL,
  bn, forward_bn,
  &_13_BatchNormalization_output_0_chain,
  NULL, &_14_MaxPool_output_0_layer, AI_STATIC, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _12_Relu_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_11_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_12_Relu_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _12_Relu_output_0_layer, 12,
  NL_TYPE, 0x0, NULL,
  nl, forward_relu,
  &_12_Relu_output_0_chain,
  NULL, &_13_BatchNormalization_output_0_layer, AI_STATIC, 
  .nl_params = NULL, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _11_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_10_BatchNormalization_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_11_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_11_Conv_output_0_weights, &_11_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_11_Conv_output_0_scratch0, NULL)
)

AI_LAYER_OBJ_DECLARE(
  _11_Conv_output_0_layer, 11,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_if32of32wf32,
  &_11_Conv_output_0_chain,
  NULL, &_12_Relu_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_SAME, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _10_BatchNormalization_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_9_Relu_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_10_BatchNormalization_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_10_BatchNormalization_output_0_scale, &_10_BatchNormalization_output_0_bias),
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _10_BatchNormalization_output_0_layer, 10,
  BN_TYPE, 0x0, NULL,
  bn, forward_bn,
  &_10_BatchNormalization_output_0_chain,
  NULL, &_11_Conv_output_0_layer, AI_STATIC, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _9_Relu_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_8_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_9_Relu_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _9_Relu_output_0_layer, 9,
  NL_TYPE, 0x0, NULL,
  nl, forward_relu,
  &_9_Relu_output_0_chain,
  NULL, &_10_BatchNormalization_output_0_layer, AI_STATIC, 
  .nl_params = NULL, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _8_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_6_MaxPool_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_8_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_8_Conv_output_0_weights, &_8_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_8_Conv_output_0_scratch0, NULL)
)

AI_LAYER_OBJ_DECLARE(
  _8_Conv_output_0_layer, 8,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_if32of32wf32,
  &_8_Conv_output_0_chain,
  NULL, &_9_Relu_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_SAME, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _6_MaxPool_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_5_BatchNormalization_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_6_MaxPool_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _6_MaxPool_output_0_layer, 7,
  POOL_TYPE, 0x0, NULL,
  pool, forward_mp,
  &_6_MaxPool_output_0_chain,
  NULL, &_8_Conv_output_0_layer, AI_STATIC, 
  .pool_size = AI_SHAPE_2D_INIT(2, 2), 
  .pool_stride = AI_SHAPE_2D_INIT(2, 2), 
  .pool_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _5_BatchNormalization_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_4_Relu_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_5_BatchNormalization_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_5_BatchNormalization_output_0_scale, &_5_BatchNormalization_output_0_bias),
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _5_BatchNormalization_output_0_layer, 6,
  BN_TYPE, 0x0, NULL,
  bn, forward_bn,
  &_5_BatchNormalization_output_0_chain,
  NULL, &_6_MaxPool_output_0_layer, AI_STATIC, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _4_Relu_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_3_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_4_Relu_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _4_Relu_output_0_layer, 5,
  NL_TYPE, 0x0, NULL,
  nl, forward_relu,
  &_4_Relu_output_0_chain,
  NULL, &_5_BatchNormalization_output_0_layer, AI_STATIC, 
  .nl_params = NULL, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _3_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_2_BatchNormalization_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_3_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_3_Conv_output_0_weights, &_3_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_3_Conv_output_0_scratch0, NULL)
)

AI_LAYER_OBJ_DECLARE(
  _3_Conv_output_0_layer, 4,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_if32of32wf32,
  &_3_Conv_output_0_chain,
  NULL, &_4_Relu_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_SAME, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _2_BatchNormalization_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_1_Relu_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_2_BatchNormalization_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_2_BatchNormalization_output_0_scale, &_2_BatchNormalization_output_0_bias),
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _2_BatchNormalization_output_0_layer, 3,
  BN_TYPE, 0x0, NULL,
  bn, forward_bn,
  &_2_BatchNormalization_output_0_chain,
  NULL, &_3_Conv_output_0_layer, AI_STATIC, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _1_Relu_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_0_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_1_Relu_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _1_Relu_output_0_layer, 2,
  NL_TYPE, 0x0, NULL,
  nl, forward_relu,
  &_1_Relu_output_0_chain,
  NULL, &_2_BatchNormalization_output_0_layer, AI_STATIC, 
  .nl_params = NULL, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _0_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &input_Transpose_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_0_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_0_Conv_output_0_weights, &_0_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_0_Conv_output_0_scratch0, NULL)
)

AI_LAYER_OBJ_DECLARE(
  _0_Conv_output_0_layer, 1,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_if32of32wf32,
  &_0_Conv_output_0_chain,
  NULL, &_1_Relu_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_SAME, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  input_Transpose_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &input_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &input_Transpose_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  input_Transpose_layer, 2,
  TRANSPOSE_TYPE, 0x0, NULL,
  transpose, forward_transpose,
  &input_Transpose_chain,
  NULL, &_0_Conv_output_0_layer, AI_STATIC, 
  .out_mapping = AI_SHAPE_INIT(6, AI_SHAPE_IN_CHANNEL, AI_SHAPE_HEIGHT, AI_SHAPE_CHANNEL, AI_SHAPE_WIDTH, AI_SHAPE_DEPTH, AI_SHAPE_EXTENSION), 
)


#if (AI_TOOLS_API_VERSION < AI_TOOLS_API_VERSION_1_5)

AI_NETWORK_OBJ_DECLARE(
  AI_NET_OBJ_INSTANCE, AI_STATIC,
  AI_BUFFER_INIT(AI_FLAG_NONE,  AI_BUFFER_FORMAT_U8,
    AI_BUFFER_SHAPE_INIT(AI_SHAPE_BCWH, 4, 1, 591932, 1, 1),
    591932, NULL, NULL),
  AI_BUFFER_INIT(AI_FLAG_NONE,  AI_BUFFER_FORMAT_U8,
    AI_BUFFER_SHAPE_INIT(AI_SHAPE_BCWH, 4, 1, 97048, 1, 1),
    97048, NULL, NULL),
  AI_TENSOR_LIST_IO_OBJ_INIT(AI_FLAG_NONE, AI_CIFAR10_IN_NUM, &input_output),
  AI_TENSOR_LIST_IO_OBJ_INIT(AI_FLAG_NONE, AI_CIFAR10_OUT_NUM, &output_output),
  &input_Transpose_layer, 0xd4447cb3, NULL)

#else

AI_NETWORK_OBJ_DECLARE(
  AI_NET_OBJ_INSTANCE, AI_STATIC,
  AI_BUFFER_ARRAY_OBJ_INIT_STATIC(
  	AI_FLAG_NONE, 1,
    AI_BUFFER_INIT(AI_FLAG_NONE,  AI_BUFFER_FORMAT_U8,
      AI_BUFFER_SHAPE_INIT(AI_SHAPE_BCWH, 4, 1, 591932, 1, 1),
      591932, NULL, NULL)
  ),
  AI_BUFFER_ARRAY_OBJ_INIT_STATIC(
  	AI_FLAG_NONE, 1,
    AI_BUFFER_INIT(AI_FLAG_NONE,  AI_BUFFER_FORMAT_U8,
      AI_BUFFER_SHAPE_INIT(AI_SHAPE_BCWH, 4, 1, 97048, 1, 1),
      97048, NULL, NULL)
  ),
  AI_TENSOR_LIST_IO_OBJ_INIT(AI_FLAG_NONE, AI_CIFAR10_IN_NUM, &input_output),
  AI_TENSOR_LIST_IO_OBJ_INIT(AI_FLAG_NONE, AI_CIFAR10_OUT_NUM, &output_output),
  &input_Transpose_layer, 0xd4447cb3, NULL)

#endif	/*(AI_TOOLS_API_VERSION < AI_TOOLS_API_VERSION_1_5)*/



/******************************************************************************/
AI_DECLARE_STATIC
ai_bool cifar10_configure_activations(
  ai_network* net_ctx, const ai_network_params* params)
{
  AI_ASSERT(net_ctx)

  if (ai_platform_get_activations_map(g_cifar10_activations_map, 1, params)) {
    /* Updating activations (byte) offsets */
    
    input_output_array.data = AI_PTR(g_cifar10_activations_map[0] + 12480);
    input_output_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 12480);
    input_Transpose_output_array.data = AI_PTR(g_cifar10_activations_map[0] + 192);
    input_Transpose_output_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 192);
    _0_Conv_output_0_scratch0_array.data = AI_PTR(g_cifar10_activations_map[0] + 0);
    _0_Conv_output_0_scratch0_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 0);
    _0_Conv_output_0_output_array.data = AI_PTR(g_cifar10_activations_map[0] + 12480);
    _0_Conv_output_0_output_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 12480);
    _1_Relu_output_0_output_array.data = AI_PTR(g_cifar10_activations_map[0] + 12480);
    _1_Relu_output_0_output_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 12480);
    _2_BatchNormalization_output_0_output_array.data = AI_PTR(g_cifar10_activations_map[0] + 12480);
    _2_BatchNormalization_output_0_output_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 12480);
    _3_Conv_output_0_scratch0_array.data = AI_PTR(g_cifar10_activations_map[0] + 0);
    _3_Conv_output_0_scratch0_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 0);
    _3_Conv_output_0_output_array.data = AI_PTR(g_cifar10_activations_map[0] + 7024);
    _3_Conv_output_0_output_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 7024);
    _4_Relu_output_0_output_array.data = AI_PTR(g_cifar10_activations_map[0] + 7024);
    _4_Relu_output_0_output_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 7024);
    _5_BatchNormalization_output_0_output_array.data = AI_PTR(g_cifar10_activations_map[0] + 7024);
    _5_BatchNormalization_output_0_output_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 7024);
    _6_MaxPool_output_0_output_array.data = AI_PTR(g_cifar10_activations_map[0] + 7024);
    _6_MaxPool_output_0_output_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 7024);
    _8_Conv_output_0_scratch0_array.data = AI_PTR(g_cifar10_activations_map[0] + 0);
    _8_Conv_output_0_scratch0_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 0);
    _8_Conv_output_0_output_array.data = AI_PTR(g_cifar10_activations_map[0] + 26824);
    _8_Conv_output_0_output_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 26824);
    _9_Relu_output_0_output_array.data = AI_PTR(g_cifar10_activations_map[0] + 61320);
    _9_Relu_output_0_output_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 61320);
    _10_BatchNormalization_output_0_output_array.data = AI_PTR(g_cifar10_activations_map[0] + 0);
    _10_BatchNormalization_output_0_output_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 0);
    _11_Conv_output_0_scratch0_array.data = AI_PTR(g_cifar10_activations_map[0] + 34496);
    _11_Conv_output_0_scratch0_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 34496);
    _11_Conv_output_0_output_array.data = AI_PTR(g_cifar10_activations_map[0] + 37312);
    _11_Conv_output_0_output_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 37312);
    _12_Relu_output_0_output_array.data = AI_PTR(g_cifar10_activations_map[0] + 0);
    _12_Relu_output_0_output_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 0);
    _13_BatchNormalization_output_0_output_array.data = AI_PTR(g_cifar10_activations_map[0] + 29744);
    _13_BatchNormalization_output_0_output_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 29744);
    _14_MaxPool_output_0_output_array.data = AI_PTR(g_cifar10_activations_map[0] + 0);
    _14_MaxPool_output_0_output_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 0);
    _16_Conv_output_0_scratch0_array.data = AI_PTR(g_cifar10_activations_map[0] + 6336);
    _16_Conv_output_0_scratch0_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 6336);
    _16_Conv_output_0_output_array.data = AI_PTR(g_cifar10_activations_map[0] + 9152);
    _16_Conv_output_0_output_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 9152);
    _17_Relu_output_0_output_array.data = AI_PTR(g_cifar10_activations_map[0] + 0);
    _17_Relu_output_0_output_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 0);
    _19_Conv_output_0_scratch0_array.data = AI_PTR(g_cifar10_activations_map[0] + 8900);
    _19_Conv_output_0_scratch0_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 8900);
    _19_Conv_output_0_output_array.data = AI_PTR(g_cifar10_activations_map[0] + 9256);
    _19_Conv_output_0_output_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 9256);
    _20_Relu_output_0_output_array.data = AI_PTR(g_cifar10_activations_map[0] + 22056);
    _20_Relu_output_0_output_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 22056);
    _21_BatchNormalization_output_0_output_array.data = AI_PTR(g_cifar10_activations_map[0] + 0);
    _21_BatchNormalization_output_0_output_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 0);
    _22_GlobalAveragePool_output_0_output_array.data = AI_PTR(g_cifar10_activations_map[0] + 12800);
    _22_GlobalAveragePool_output_0_output_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 12800);
    _24_Gemm_output_0_output_array.data = AI_PTR(g_cifar10_activations_map[0] + 0);
    _24_Gemm_output_0_output_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 0);
    _25_Relu_output_0_output_array.data = AI_PTR(g_cifar10_activations_map[0] + 512);
    _25_Relu_output_0_output_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 512);
    output_output_array.data = AI_PTR(g_cifar10_activations_map[0] + 0);
    output_output_array.data_start = AI_PTR(g_cifar10_activations_map[0] + 0);
    return true;
  }
  AI_ERROR_TRAP(net_ctx, INIT_FAILED, NETWORK_ACTIVATIONS);
  return false;
}




/******************************************************************************/
AI_DECLARE_STATIC
ai_bool cifar10_configure_weights(
  ai_network* net_ctx, const ai_network_params* params)
{
  AI_ASSERT(net_ctx)

  if (ai_platform_get_weights_map(g_cifar10_weights_map, 1, params)) {
    /* Updating weights (byte) offsets */
    
    _0_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _0_Conv_output_0_weights_array.data = AI_PTR(g_cifar10_weights_map[0] + 0);
    _0_Conv_output_0_weights_array.data_start = AI_PTR(g_cifar10_weights_map[0] + 0);
    _0_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _0_Conv_output_0_bias_array.data = AI_PTR(g_cifar10_weights_map[0] + 4224);
    _0_Conv_output_0_bias_array.data_start = AI_PTR(g_cifar10_weights_map[0] + 4224);
    _2_BatchNormalization_output_0_scale_array.format |= AI_FMT_FLAG_CONST;
    _2_BatchNormalization_output_0_scale_array.data = AI_PTR(g_cifar10_weights_map[0] + 4312);
    _2_BatchNormalization_output_0_scale_array.data_start = AI_PTR(g_cifar10_weights_map[0] + 4312);
    _2_BatchNormalization_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _2_BatchNormalization_output_0_bias_array.data = AI_PTR(g_cifar10_weights_map[0] + 4400);
    _2_BatchNormalization_output_0_bias_array.data_start = AI_PTR(g_cifar10_weights_map[0] + 4400);
    _3_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _3_Conv_output_0_weights_array.data = AI_PTR(g_cifar10_weights_map[0] + 4488);
    _3_Conv_output_0_weights_array.data_start = AI_PTR(g_cifar10_weights_map[0] + 4488);
    _3_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _3_Conv_output_0_bias_array.data = AI_PTR(g_cifar10_weights_map[0] + 35464);
    _3_Conv_output_0_bias_array.data_start = AI_PTR(g_cifar10_weights_map[0] + 35464);
    _5_BatchNormalization_output_0_scale_array.format |= AI_FMT_FLAG_CONST;
    _5_BatchNormalization_output_0_scale_array.data = AI_PTR(g_cifar10_weights_map[0] + 35552);
    _5_BatchNormalization_output_0_scale_array.data_start = AI_PTR(g_cifar10_weights_map[0] + 35552);
    _5_BatchNormalization_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _5_BatchNormalization_output_0_bias_array.data = AI_PTR(g_cifar10_weights_map[0] + 35640);
    _5_BatchNormalization_output_0_bias_array.data_start = AI_PTR(g_cifar10_weights_map[0] + 35640);
    _8_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _8_Conv_output_0_weights_array.data = AI_PTR(g_cifar10_weights_map[0] + 35728);
    _8_Conv_output_0_weights_array.data_start = AI_PTR(g_cifar10_weights_map[0] + 35728);
    _8_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _8_Conv_output_0_bias_array.data = AI_PTR(g_cifar10_weights_map[0] + 97680);
    _8_Conv_output_0_bias_array.data_start = AI_PTR(g_cifar10_weights_map[0] + 97680);
    _10_BatchNormalization_output_0_scale_array.format |= AI_FMT_FLAG_CONST;
    _10_BatchNormalization_output_0_scale_array.data = AI_PTR(g_cifar10_weights_map[0] + 97856);
    _10_BatchNormalization_output_0_scale_array.data_start = AI_PTR(g_cifar10_weights_map[0] + 97856);
    _10_BatchNormalization_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _10_BatchNormalization_output_0_bias_array.data = AI_PTR(g_cifar10_weights_map[0] + 98032);
    _10_BatchNormalization_output_0_bias_array.data_start = AI_PTR(g_cifar10_weights_map[0] + 98032);
    _11_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _11_Conv_output_0_weights_array.data = AI_PTR(g_cifar10_weights_map[0] + 98208);
    _11_Conv_output_0_weights_array.data_start = AI_PTR(g_cifar10_weights_map[0] + 98208);
    _11_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _11_Conv_output_0_bias_array.data = AI_PTR(g_cifar10_weights_map[0] + 222112);
    _11_Conv_output_0_bias_array.data_start = AI_PTR(g_cifar10_weights_map[0] + 222112);
    _13_BatchNormalization_output_0_scale_array.format |= AI_FMT_FLAG_CONST;
    _13_BatchNormalization_output_0_scale_array.data = AI_PTR(g_cifar10_weights_map[0] + 222288);
    _13_BatchNormalization_output_0_scale_array.data_start = AI_PTR(g_cifar10_weights_map[0] + 222288);
    _13_BatchNormalization_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _13_BatchNormalization_output_0_bias_array.data = AI_PTR(g_cifar10_weights_map[0] + 222464);
    _13_BatchNormalization_output_0_bias_array.data_start = AI_PTR(g_cifar10_weights_map[0] + 222464);
    _16_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _16_Conv_output_0_weights_array.data = AI_PTR(g_cifar10_weights_map[0] + 222640);
    _16_Conv_output_0_weights_array.data_start = AI_PTR(g_cifar10_weights_map[0] + 222640);
    _16_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _16_Conv_output_0_bias_array.data = AI_PTR(g_cifar10_weights_map[0] + 473264);
    _16_Conv_output_0_bias_array.data_start = AI_PTR(g_cifar10_weights_map[0] + 473264);
    _19_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _19_Conv_output_0_weights_array.data = AI_PTR(g_cifar10_weights_map[0] + 473620);
    _19_Conv_output_0_weights_array.data_start = AI_PTR(g_cifar10_weights_map[0] + 473620);
    _19_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _19_Conv_output_0_bias_array.data = AI_PTR(g_cifar10_weights_map[0] + 519188);
    _19_Conv_output_0_bias_array.data_start = AI_PTR(g_cifar10_weights_map[0] + 519188);
    _21_BatchNormalization_output_0_scale_array.format |= AI_FMT_FLAG_CONST;
    _21_BatchNormalization_output_0_scale_array.data = AI_PTR(g_cifar10_weights_map[0] + 519700);
    _21_BatchNormalization_output_0_scale_array.data_start = AI_PTR(g_cifar10_weights_map[0] + 519700);
    _21_BatchNormalization_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _21_BatchNormalization_output_0_bias_array.data = AI_PTR(g_cifar10_weights_map[0] + 520212);
    _21_BatchNormalization_output_0_bias_array.data_start = AI_PTR(g_cifar10_weights_map[0] + 520212);
    _24_Gemm_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _24_Gemm_output_0_weights_array.data = AI_PTR(g_cifar10_weights_map[0] + 520724);
    _24_Gemm_output_0_weights_array.data_start = AI_PTR(g_cifar10_weights_map[0] + 520724);
    _24_Gemm_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _24_Gemm_output_0_bias_array.data = AI_PTR(g_cifar10_weights_map[0] + 586260);
    _24_Gemm_output_0_bias_array.data_start = AI_PTR(g_cifar10_weights_map[0] + 586260);
    output_weights_array.format |= AI_FMT_FLAG_CONST;
    output_weights_array.data = AI_PTR(g_cifar10_weights_map[0] + 586772);
    output_weights_array.data_start = AI_PTR(g_cifar10_weights_map[0] + 586772);
    output_bias_array.format |= AI_FMT_FLAG_CONST;
    output_bias_array.data = AI_PTR(g_cifar10_weights_map[0] + 591892);
    output_bias_array.data_start = AI_PTR(g_cifar10_weights_map[0] + 591892);
    return true;
  }
  AI_ERROR_TRAP(net_ctx, INIT_FAILED, NETWORK_WEIGHTS);
  return false;
}


/**  PUBLIC APIs SECTION  *****************************************************/



AI_DEPRECATED
AI_API_ENTRY
ai_bool ai_cifar10_get_info(
  ai_handle network, ai_network_report* report)
{
  ai_network* net_ctx = AI_NETWORK_ACQUIRE_CTX(network);

  if (report && net_ctx)
  {
    ai_network_report r = {
      .model_name        = AI_CIFAR10_MODEL_NAME,
      .model_signature   = AI_CIFAR10_MODEL_SIGNATURE,
      .model_datetime    = AI_TOOLS_DATE_TIME,
      
      .compile_datetime  = AI_TOOLS_COMPILE_TIME,
      
      .runtime_revision  = ai_platform_runtime_get_revision(),
      .runtime_version   = ai_platform_runtime_get_version(),

      .tool_revision     = AI_TOOLS_REVISION_ID,
      .tool_version      = {AI_TOOLS_VERSION_MAJOR, AI_TOOLS_VERSION_MINOR,
                            AI_TOOLS_VERSION_MICRO, 0x0},
      .tool_api_version  = AI_STRUCT_INIT,

      .api_version            = ai_platform_api_get_version(),
      .interface_api_version  = ai_platform_interface_api_get_version(),
      
      .n_macc            = 18338190,
      .n_inputs          = 0,
      .inputs            = NULL,
      .n_outputs         = 0,
      .outputs           = NULL,
      .params            = AI_STRUCT_INIT,
      .activations       = AI_STRUCT_INIT,
      .n_nodes           = 0,
      .signature         = 0xd4447cb3,
    };

    if (!ai_platform_api_get_network_report(network, &r)) return false;

    *report = r;
    return true;
  }
  return false;
}



AI_API_ENTRY
ai_bool ai_cifar10_get_report(
  ai_handle network, ai_network_report* report)
{
  ai_network* net_ctx = AI_NETWORK_ACQUIRE_CTX(network);

  if (report && net_ctx)
  {
    ai_network_report r = {
      .model_name        = AI_CIFAR10_MODEL_NAME,
      .model_signature   = AI_CIFAR10_MODEL_SIGNATURE,
      .model_datetime    = AI_TOOLS_DATE_TIME,
      
      .compile_datetime  = AI_TOOLS_COMPILE_TIME,
      
      .runtime_revision  = ai_platform_runtime_get_revision(),
      .runtime_version   = ai_platform_runtime_get_version(),

      .tool_revision     = AI_TOOLS_REVISION_ID,
      .tool_version      = {AI_TOOLS_VERSION_MAJOR, AI_TOOLS_VERSION_MINOR,
                            AI_TOOLS_VERSION_MICRO, 0x0},
      .tool_api_version  = AI_STRUCT_INIT,

      .api_version            = ai_platform_api_get_version(),
      .interface_api_version  = ai_platform_interface_api_get_version(),
      
      .n_macc            = 18338190,
      .n_inputs          = 0,
      .inputs            = NULL,
      .n_outputs         = 0,
      .outputs           = NULL,
      .map_signature     = AI_MAGIC_SIGNATURE,
      .map_weights       = AI_STRUCT_INIT,
      .map_activations   = AI_STRUCT_INIT,
      .n_nodes           = 0,
      .signature         = 0xd4447cb3,
    };

    if (!ai_platform_api_get_network_report(network, &r)) return false;

    *report = r;
    return true;
  }
  return false;
}


AI_API_ENTRY
ai_error ai_cifar10_get_error(ai_handle network)
{
  return ai_platform_network_get_error(network);
}


AI_API_ENTRY
ai_error ai_cifar10_create(
  ai_handle* network, const ai_buffer* network_config)
{
  return ai_platform_network_create(
    network, network_config, 
    AI_CONTEXT_OBJ(&AI_NET_OBJ_INSTANCE),
    AI_TOOLS_API_VERSION_MAJOR, AI_TOOLS_API_VERSION_MINOR, AI_TOOLS_API_VERSION_MICRO);
}


AI_API_ENTRY
ai_error ai_cifar10_create_and_init(
  ai_handle* network, const ai_handle activations[], const ai_handle weights[])
{
  ai_error err;
  ai_network_params params;

  err = ai_cifar10_create(network, AI_CIFAR10_DATA_CONFIG);
  if (err.type != AI_ERROR_NONE) {
    return err;
  }
  
  if (ai_cifar10_data_params_get(&params) != true) {
    err = ai_cifar10_get_error(*network);
    return err;
  }
#if defined(AI_CIFAR10_DATA_ACTIVATIONS_COUNT)
  /* set the addresses of the activations buffers */
  for (ai_u16 idx=0; activations && idx<params.map_activations.size; idx++) {
    AI_BUFFER_ARRAY_ITEM_SET_ADDRESS(&params.map_activations, idx, activations[idx]);
  }
#endif
#if defined(AI_CIFAR10_DATA_WEIGHTS_COUNT)
  /* set the addresses of the weight buffers */
  for (ai_u16 idx=0; weights && idx<params.map_weights.size; idx++) {
    AI_BUFFER_ARRAY_ITEM_SET_ADDRESS(&params.map_weights, idx, weights[idx]);
  }
#endif
  if (ai_cifar10_init(*network, &params) != true) {
    err = ai_cifar10_get_error(*network);
  }
  return err;
}


AI_API_ENTRY
ai_buffer* ai_cifar10_inputs_get(ai_handle network, ai_u16 *n_buffer)
{
  if (network == AI_HANDLE_NULL) {
    network = (ai_handle)&AI_NET_OBJ_INSTANCE;
    AI_NETWORK_OBJ(network)->magic = AI_MAGIC_CONTEXT_TOKEN;
  }
  return ai_platform_inputs_get(network, n_buffer);
}


AI_API_ENTRY
ai_buffer* ai_cifar10_outputs_get(ai_handle network, ai_u16 *n_buffer)
{
  if (network == AI_HANDLE_NULL) {
    network = (ai_handle)&AI_NET_OBJ_INSTANCE;
    AI_NETWORK_OBJ(network)->magic = AI_MAGIC_CONTEXT_TOKEN;
  }
  return ai_platform_outputs_get(network, n_buffer);
}


AI_API_ENTRY
ai_handle ai_cifar10_destroy(ai_handle network)
{
  return ai_platform_network_destroy(network);
}


AI_API_ENTRY
ai_bool ai_cifar10_init(
  ai_handle network, const ai_network_params* params)
{
  ai_network* net_ctx = AI_NETWORK_OBJ(ai_platform_network_init(network, params));
  ai_bool ok = true;

  if (!net_ctx) return false;
  ok &= cifar10_configure_weights(net_ctx, params);
  ok &= cifar10_configure_activations(net_ctx, params);

  ok &= ai_platform_network_post_init(network);

  return ok;
}


AI_API_ENTRY
ai_i32 ai_cifar10_run(
  ai_handle network, const ai_buffer* input, ai_buffer* output)
{
  return ai_platform_network_process(network, input, output);
}


AI_API_ENTRY
ai_i32 ai_cifar10_forward(ai_handle network, const ai_buffer* input)
{
  return ai_platform_network_process(network, input, NULL);
}



#undef AI_CIFAR10_MODEL_SIGNATURE
#undef AI_NET_OBJ_INSTANCE
#undef AI_TOOLS_DATE_TIME
#undef AI_TOOLS_COMPILE_TIME

