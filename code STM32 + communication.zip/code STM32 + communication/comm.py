import serial
import numpy as np

PORT = "COM9"
BAUD = 115200
TIMEOUT = 20

def synchronise_UART(s):
    while True:
        s.write(b"\xAB")
        ret = s.read(1)
        if ret == b"\xCD":
            # lire l'octet additionnel envoyé par la STM32 si présent
            _ = s.read(1)
            break

def send_inputs_to_STM32(img, s):
    # img : H x W x C (uint8 0..255) ou already float normalized in [-1,1]
    # Convertir en float32 normalisé si nécessaire
    if img.dtype == np.uint8:
        f = (img.astype(np.float32) / 255.0) * 2.0 - 1.0
    else:
        f = img.astype(np.float32)
    # Réordonner en C,H,W
    f_chw = np.transpose(f, (2, 0, 1)).copy()
    # Envoyer en float32 little-endian
    s.write(f_chw.astype(np.float32).tobytes())

def read_output_from_STM32(s):
    out = s.read(10)
    if len(out) != 10:
        raise RuntimeError("Timeout or incomplete read")
    float_values = [b / 255.0 for b in out]
    return float_values

if __name__ == "__main__":
    import random
    from torchvision import datasets

    # Charger le jeu de test CIFAR-10 (téléchargera dans ./data si nécessaire)
    cifar10_test = datasets.CIFAR10(root="./data", train=False, download=True)
    # cifar10_test.data : numpy array uint8 shape (10000, H, W, C)
    # cifar10_test.targets : list of int labels length 10000
    X_test = cifar10_test.data  # uint8 H,W,C
    Y_test = np.array(cifar10_test.targets)  # int labels

    random_seed = None  # mettre une valeur (ex: 42) pour reproductibilité
    random.seed(random_seed)
    np.random.seed(random_seed)

    total_samples = len(X_test)
    sample_count = 100
    if sample_count <= total_samples:
        indices = random.sample(range(total_samples), sample_count)
    else:
        indices = [random.randrange(total_samples) for _ in range(sample_count)]

    with serial.Serial(PORT, BAUD, timeout=TIMEOUT) as ser:
        print("Synchronising...")
        synchronise_UART(ser)
        print("Synchronised")

        correct = 0
        for idx_i, i in enumerate(indices, start=1):
            img = X_test[i]  # H,W,C uint8
            send_inputs_to_STM32(img, ser)
            out = read_output_from_STM32(ser)
            pred = int(np.argmax(out))
            true = int(Y_test[i])
            if pred == true:
                correct += 1
            print(f"{idx_i}/{sample_count} idx={i} true={true} pred={pred} probs={out}")
        print(f"Accuracy on {sample_count} random samples: {correct}/{sample_count} = {correct/sample_count:.3f}")